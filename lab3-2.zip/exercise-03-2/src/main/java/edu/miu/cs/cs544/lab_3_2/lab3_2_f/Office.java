package edu.miu.cs.cs544.lab3_2_f;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter @Setter
@EqualsAndHashCode
@ToString
@Entity
@Table(name = "office")
public class Office {

	@Id
	@GeneratedValue
	private Long id;
	private Integer roomNumber;
	private String building;
	@OneToMany(mappedBy = "office")
	private Set<Employee> employess;
	
	public Office(Integer roomNumber, String building) {
		this.roomNumber = roomNumber;
		this.building = building;
		this.employess = new HashSet<>();
	}
}
