package edu.miu.cs.cs544.app;

import java.util.Arrays;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import edu.miu.cs.cs544.examples.HibernateUtils;

public class App {

	private static final SessionFactory sessionFactory;
	private Transaction tx;
	
	static {
		// If there is more than one entity, you will have to pass them as a comma delimited argument list to the method below
		sessionFactory = HibernateUtils.getSessionFactory(Arrays.asList(
				edu.miu.cs.cs544.lab3_2_a.Department.class, edu.miu.cs.cs544.lab3_2_a.Employee.class,
				edu.miu.cs.cs544.lab3_2_b.Book.class, edu.miu.cs.cs544.lab3_2_b.Publisher.class,
				edu.miu.cs.cs544.lab3_2_c.Course.class, edu.miu.cs.cs544.lab3_2_c.Student.class,
				edu.miu.cs.cs544.lab3_2_d.Customer.class, edu.miu.cs.cs544.lab3_2_d.Reservation.class,
				edu.miu.cs.cs544.lab3_2_e.Book.class, edu.miu.cs.cs544.lab3_2_e.Customer.class, edu.miu.cs.cs544.lab3_2_e.Reservation.class,
				edu.miu.cs.cs544.lab3_2_f.Department.class, edu.miu.cs.cs544.lab3_2_f.Employee.class,edu.miu.cs.cs544.lab3_2_f.Office.class
		));
	}
	
	public static void main(String[] args) {
		App app = new App();
		//A
		
		//B
		edu.miu.cs.cs544.lab3_2_b.Book book1 = new edu.miu.cs.cs544.lab3_2_b.Book(123, "Title", "Author");
		edu.miu.cs.cs544.lab3_2_b.Publisher publisher1 = new edu.miu.cs.cs544.lab3_2_b.Publisher("publisher 1");
		book1.setPublisher(publisher1);
		app.saveOrUpdate(publisher1);
		app.saveOrUpdate(book1);
		
		//C
		//D
		//E
		//F
	}
	
	//used because we are using cascade persist, so when we have the same owner detached obj problem may occur 
	public void saveOrUpdate(Object obj) {
		try(Session session = sessionFactory.openSession()) {
			tx = session.beginTransaction();
			session.persist(obj);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
		}
	}
	
	public void print(Object obj) {
		try(Session session = sessionFactory.openSession()) {
			tx = session.beginTransaction();
			List<Object> list = session.createQuery("from "+obj.getClass().getSimpleName(), Object.class).list();
			list.forEach(o -> System.out.println(o));
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
		}
	}
}
