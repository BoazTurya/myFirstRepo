package repository;

import java.util.List;

import model.Faculty;

public class FSAPrepository {
	List<Faculty> facultyData;

	public FSAPrepository(List<Faculty> data) {
		facultyData=data;
	}

	public List<Faculty> getFacultyData() {
		return facultyData;
	}

	public void setFacultyData(List<Faculty> facultyData) {
		this.facultyData = facultyData;
	}

}
