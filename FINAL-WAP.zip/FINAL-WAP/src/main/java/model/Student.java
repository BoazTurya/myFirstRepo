package model;

import java.time.LocalDate;

public class Student {
	private String studentID;
	private String name;
	private LocalDate admissionDate;
	private Double cgpa;
	private Faculty advisor;

	public Student(Faculty advisor,String studentID,String name, LocalDate admissionDate,Double cgpa) {
		this.studentID = studentID;
		this.name = name;
		this.admissionDate = admissionDate;
		this.cgpa = cgpa;
		this.advisor = advisor;		
	}

	public String getStudentID() {
		return studentID;
	}

	public void setStudentID(String studentID) {
		this.studentID = studentID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getAdmissionDate() {
		return admissionDate;
	}

	public void setAdmissionDate(LocalDate admissionDate) {
		this.admissionDate = admissionDate;
	}

	public Double getCgpa() {
		return cgpa;
	}

	public void setCgpa(Double cgpa) {
		this.cgpa = cgpa;
	}

	public Faculty getAdvisor() {
		return advisor;
	}

	public void setAdvisor(Faculty advisor) {
		this.advisor = advisor;
	}
	

}
