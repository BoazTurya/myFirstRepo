package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Faculty {
	private String facultyID;
	private String name;
	private String email;
	List<Student> advisees = new ArrayList<>();

	public Faculty(String facultyID, String name, String email) {
		this.facultyID = facultyID;
		this.name = name;
		this.email = email;
	}
	public void addStudent(String studentID,String stdName, LocalDate admissionDate,Double cgpa) {
		Student newAdvisee = new Student(this,studentID,stdName,admissionDate,cgpa);
		advisees.add(newAdvisee);
	}
	public String getFacultyID() {
		return facultyID;
	}
	public void setFacultyID(String facultyID) {
		this.facultyID = facultyID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public List<Student> getAdvisees() {
		return advisees;
	}
	public void setAdvisees(List<Student> advisees) {
		this.advisees = advisees;
	}

}
