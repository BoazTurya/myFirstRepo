package controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Vector;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import facultyService.FacultyService;
import model.Faculty;



/**
 * Servlet implementation class facultyController
 */
@WebServlet({"/facultyController","/facultylist"})
public class facultyController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	FacultyService facService;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public facultyController() {
        super();
        // TODO Auto-generated constructor stub
    }
    @Override
	public void init(ServletConfig config) throws ServletException {
		ServletContext context = config.getServletContext();
		if(context.getAttribute("facultyData")==null) {
			List<Faculty> facultyData = new Vector<>();
			
			Faculty one = new Faculty("F101","John R. Williamson","jrw@miu.edu");
			Faculty two = new Faculty("F102","Anna B. Lewis","ablewis@miu.edu");
			Faculty three = new Faculty("F103","Cameron J. Moll", "cjmoll@miu.edu");
			
			one.addStudent("000-61-0001", "Bob Jones", LocalDate.of(2019, 10,4), 3.54);
			one.addStudent("123-45-6789", "Usain Bolt", LocalDate.of(2020, 2,29), 4.0);
			two.addStudent("000-61-0001", "Maria Rogriguez", LocalDate.of(2019, 8,15), 3.77);
			
			facultyData.add(one);
			facultyData.add(two);
			facultyData.add(three);
			
			this.facService = new FacultyService(facultyData);
			context.setAttribute("facultyData", this.facService.getFacultyDataSortedReversed());	
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.getRequestDispatcher("/WEB-INF/views/faculty.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
