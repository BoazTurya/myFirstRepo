package facultyService;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import model.Faculty;
import repository.FSAPrepository;

public class FacultyService {
	FSAPrepository repository;

	public FacultyService(List<Faculty> data) {
		repository = new FSAPrepository(data);
	}
	public List<Faculty> getFacultyDataSortedReversed() {
		return repository.getFacultyData().stream()
				.sorted(Comparator.comparing(Faculty::getName).reversed()).collect(Collectors.toList());
	}
}
